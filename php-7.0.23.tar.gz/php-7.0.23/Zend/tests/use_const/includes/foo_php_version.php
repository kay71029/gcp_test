<?php

namespace foo;

const PHP_VERSION = 42;
